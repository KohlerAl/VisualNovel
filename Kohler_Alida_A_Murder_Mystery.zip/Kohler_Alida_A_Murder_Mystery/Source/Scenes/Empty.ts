namespace AMurderMystery {
    export async function Empty(): ƒS.SceneReturn { 
       console.log("The End");  
    }

}